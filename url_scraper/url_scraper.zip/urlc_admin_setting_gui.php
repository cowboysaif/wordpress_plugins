<?php
	$full_url;
	$depth; 
	ignore_user_abort(true);
	set_time_limit(0);
	include('scraper.php');
    $similar_word_flag = true;
   if ($_POST["hiddenField"] == "submitted" ) {
	   $similar_word_flag;
	   if ( isset($_POST['similar_words']) ) {
		if ( $_POST['similar_words'] == 'false' ) {
			$similar_word_flag = false; 
		}
		else {
			$similar_word_flag = true; 
		}
	   }
	   
	   else {
		   $similar_word_flag = true; 
	   }
	  $url = $_POST['url'];
	  $extension = $_POST['exclude_extension'];
	  $word = $_POST['exclude_word'];
	  $depth = $_POST['depth'];
	  update_option('urlc_url', $url);
	  update_option('urlc_url_extension' , $extension );
	  update_option('urlc_url_word' , $title );
	  update_option('urlc_depth', $depth);
	  $exclude_extension = explode( ' , ' , $extension );
	  $exclude_word = explode ( ' , ' , $word );
	  $full_url = 'http://' . $url;	
	  //$scraper = new scraper( $full_url , intval($depth) );
  
  
  }
  
  else {
	  $url = get_option('urlc_url');
	  $extension = get_option('urlc_url_extension');
	  $word = get_option('urlc_url_word');
	  $depth = get_option('urlc_depth');
	  
  }
	  if ( get_option('urlc_on') == 'false' && get_option('urlc_download_session') == 'off' && $_POST['hiddenField'] == 'submitted') {
		
	   $scraper = new scraper( $url , $depth , $exclude_extension , $exclude_word , $similar_word_flag );
	 
	   echo '<div class = "updated"><p><strong>scraping has started in background. Hit refresh after sometime.</p></div>';
	   echo '<div class = "updated"><p><strong>' . get_option('urlc_progress') . '% done </p></div>';
	  }
	  else if ( get_option('urlc_on') == 'false' && get_option('urlc_download_session') == 'on') {
	  $disabled = '';
	  $url_path = WP_PLUGIN_URL . 'urlc.csv';
	  echo '<div class = "updated"><a href="'.$url_path.'">csv file generated. click here</a></div>';
	  update_option('urlc_download_session' , 'off' );
	  }
  
	  else if ( get_option('urlc_on') == 'false' && get_option('urlc_download_session') == 'off' && $_POST['hiddenField'] == 'submitted' ) {
	  $disabled = 'disabled = "disabled"';
	  echo '<div class = "updated"><p><strong>Server is busy creating csv file. Hit refresh after sometime.</p></div>';
	  $progress = get_option('urlc_progress');
	  echo '<div class = "updated"><p><strong>' . $progress . '% done </p></div>';
	  }
	  else {
	  
	  }
  echo '
  <div id = "wrap">
  <form name="form1" method="post" action="">
	<p>
	<input name = "hiddenField" type = "hidden" id = "hiddenField" value = "submitted"/>
	  <label for="url"></label>
	  Url of the website to scrap : http://
	  <input name="url" type="text" id="url"  value="'.$url.'" size="45">
	  
	</p>
	<p>
	  <label for="exclude_extension"></label>
	  Exclude url(s) that has a filename extension (comma separated ) : 
	  <input name = "exclude_extension" size="60" id="exclude_extension" value = "'.$extension .'"></input>
	  <img src="' . WP_PLUGIN_URL . '/url_scraper/help-ico.png" width="16" height="16" title = "Input the links "></image>
	</p>
	<p>Exclude pages that has a url containing words : (comma separated ) : 
	  <label for="exclude_word"></label>
	  <input name="exclude_word" size ="60" id="exclude_word" value = "'.$word.'"></input>
	  <img src="' . WP_PLUGIN_URL . '/url_scraper/white.png" width="16" height="16" title = "Input the links "></image> 
	  <input name="similar_words" id = "similar_words" type="checkbox" value="false"/> 
	  
	  &nbspMatch whole word&nbsp&nbsp
	  <img src="' . WP_PLUGIN_URL . '/url_scraper/help-ico.png" width="16" height="16" title = "Input the links "></image>
	
	</p>
	<p>Depth of the scraping :
	<input name = "depth" id = "depth" size = 6 value = "'.$depth.'"></input>
	</p>
  <p>   
	<input type="submit" name="submit" id="submit" ' .$disabled . ' value="Submit"></input>
  
  </p>
  </form>
  </div>';
?>
   
	  
